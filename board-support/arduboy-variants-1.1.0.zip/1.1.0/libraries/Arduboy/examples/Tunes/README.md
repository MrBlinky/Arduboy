# Tunes
Play a musical composition using the Arduboy.

A small composition is stored by `byte PROGMEM score`. The score is played in the sketch loop using `playScore(score)`.
